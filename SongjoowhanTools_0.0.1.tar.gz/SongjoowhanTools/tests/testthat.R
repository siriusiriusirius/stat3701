library(testthat)
library(SongjoowhanTools)

test_check("SongjoowhanTools")
